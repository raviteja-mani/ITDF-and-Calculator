package com.example.employeedetails;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

import androidx.annotation.Nullable;

public class RoundedImage extends androidx.appcompat.widget.AppCompatImageView {
    public RoundedImage(Context context) {
        super(context);
    }

    public RoundedImage(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public RoundedImage(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

//    public RoundedImage(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
//        super(context, attrs, defStyleAttr, defStyleRes);
//    }
}
