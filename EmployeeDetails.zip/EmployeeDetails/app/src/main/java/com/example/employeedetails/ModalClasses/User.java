package com.example.employeedetails.ModalClasses;

public class User {

    private int id;

    private String url;

    private int userId;

    private String username;

    private String first_name;

    private String last_name;

    private String email;

    private String is_active;

    private String date_joined;

    private String last_join;

}
